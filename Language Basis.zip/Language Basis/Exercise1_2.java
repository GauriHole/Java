public class Exercise1_2 {
    public static void main(String args[]){
        String s1=args[0];
        System.out.println(" Welcome "+s1);
        System.out.println(" Thank You!");
}
}
/* 
 PS E:\1_Java> javac Exercise1_2.java
 PS E:\1_Java> java Exercise1_2 John        
 Welcome John
 Thank You! */