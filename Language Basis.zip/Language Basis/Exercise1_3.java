public class Exercise1_3 {
    public static void main(String args[]){
        int var1=Integer.parseInt(args[0]);
        int var2=Integer.parseInt(args[1]);
        int add = var1+var2;
        System.out.println("The Sum of "+var1+" and "+var2+" is "+add);
}
}
/* PS E:\1_Java> javac Exercise1_3.java 
PS E:\1_Java> java Exercise1_3 10 20 
The Sum of 10 and 20 is 30 */