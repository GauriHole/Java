public class Exercise1_1A {
    public static void main(String[] args) {
        String ag1 = args[0];
        String ag2 = args[1];
        System.out.println(ag1+" Technologies "+ag2);
    }
}
/* PS E:\1_Java> javac Exercise1_1A.java 
PS E:\1_Java> java Exercise1_1A Wipro Bangalore
Wipro Technologies Bangalore */